package com.example.studentmanagementsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class expectedGrade extends AppCompatActivity {

    // Getting logged gpa
    private String currentGPAString = Background.getUsersGPA();



    private int noOfUpcomingSemesters = 0;
    private double expectedGPA = 0.0;
    private double averageGPAForUpcomingSemesters = 0.0;
    private double currentGPA = 0.0;
    private String noOfUpcomingSemestersString ;
    private String expectedGPAString ;
    private String averageGPAForUpcomingSemestersString ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expected_grade);
    }

    public void calculateExpectedGPA(View view){
        Log.d("juaexpectGPA", currentGPAString);
        //Read the no of upcoming semesters as a String and typecast it to int
        noOfUpcomingSemestersString = ((EditText)findViewById(R.id.semesters)).getText().toString();

        //Read the expected Grade as String and typecast it to double
        expectedGPAString = ((EditText)findViewById(R.id.expextedGrade)).getText().toString();

        Log.d("juaexpectGPA", currentGPAString);

        if(TextUtils.isEmpty(noOfUpcomingSemestersString) || TextUtils.isEmpty(expectedGPAString)){

            //Display Required GPA for Upcoming Semesters
            ((TextView)findViewById(R.id.averageGPAOutput1)).setText("Inputs Cannot be empty!");
            Toast.makeText(this,"Inputs Cannot be empty!!",Toast.LENGTH_LONG).show();
            return;
        }

        //Convert the Strings to double
        noOfUpcomingSemesters = Integer.parseInt(noOfUpcomingSemestersString);
        expectedGPA = Double.parseDouble(expectedGPAString);
        currentGPA = Double.parseDouble(currentGPAString);

        //Calculate the required average GPA for upcoming Semesters
        averageGPAForUpcomingSemesters = (expectedGPA * (noOfUpcomingSemesters + 1) - currentGPA) / noOfUpcomingSemesters;


        //If the Average Required is a positive number then you can achieve it otherwise not
        if(0 < averageGPAForUpcomingSemesters && averageGPAForUpcomingSemesters  <= 4){
            averageGPAForUpcomingSemestersString = "Average GPA Required : " + averageGPAForUpcomingSemesters;
            String averageGPAForUpcomingSemestersStringrounded = averageGPAForUpcomingSemestersString.substring(0,28);

            //Display Required GPA for Upcoming Semesters
            ((TextView) findViewById(R.id.averageGPAOutput1)).setText(averageGPAForUpcomingSemestersStringrounded);
        }
        else{

            //Display Required GPA for Upcoming Semesters
            ((TextView) findViewById(R.id.averageGPAOutput1)).setText("You Cannot Achieve that GPA!");
            Toast.makeText(this,"You Cannot Achieve that GPA!!",Toast.LENGTH_LONG).show();
        }

    }
}